package tasks;

public class Summation {

	private int[] arr;

	private int low, high, partial;

	public Summation(int[] arr, int low, int high) {
		this.arr = arr;
		this.low = low;
		this.high = Math.min(high, arr.length);
	}

	public int getPartialSum() {
		return partial;
	}

	public void run() {
		partial = sum(arr, low, high);
	}

	/**
	 * Suma todos los elementos del array y lo devuelve. 
	 * 
	 * @param arr
	 * @return
	 */
	public static int sum(int[] arr) {
		return sum(arr, 0, arr.length);
	}

	/**
	 * Suma los elementos que hay entre low y high (límites) del vector arr y deveulve el valor de la suma.
	 * @param arr
	 * @param low
	 * @param high
	 * @return
	 */
	public static int sum(int[] arr, int low, int high) {
		int total = 0;

		for (int i = low; i < high; i++) {
			total += arr[i];
		}

		return total;
	}

}