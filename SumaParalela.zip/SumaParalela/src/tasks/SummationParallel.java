package tasks;
public class SummationParallel extends Thread {

    private int[] arr;

    private int low, high, partial;

    public SummationParallel(int[] arr, int low, int high)
    {
        this.arr = arr;
        this.low = low;
        this.high = Math.min(high, arr.length);
    }

    /**
     * Getter para obtener el valor de la suma parcial 
     * @return
     */
    public int getPartialSum()
    {
        return partial;
    }

    /**
     * Ejecución de la tarea paralela.
     */
    public void  run()
    {
        partial = sum(arr, low, high);
    }

	/**
	 * Suma todos los elementos del array y lo devuelve.
	 * 
	 * @param arr
	 * @return
	 */
    public static int sum(int[] arr)
    {
        return sum(arr, 0, arr.length);
    }

	/**
	 * Suma los elementos que hay entre low y high (límites) del vector arr y deveulve el valor de la suma.
	 * @param arr
	 * @param low
	 * @param high
	 * @return
	 */
    public static int sum(int[] arr, int low, int high)
    {
        int total = 0;

        for (int i = low; i < high; i++) {
            total += arr[i];
        }

        return total;
    }

    /**
     * Suma los elementos del array de forma paralela y lo devuelve.
     * @param arr
     * @return
     */
    public static  int parallelSum(int[] arr)
    {
        return parallelSum(arr, 2);
    }

    /**
     * Divide el array en un número de partes (threads) y se encarga de lanzar las tareas (SummationParallel) de forma
     * paralela. 
     * @param arr
     * @param threads
     * @return
     */
    public static int parallelSum(int[] arr, int threads)
    {
    	//Averiguo el chunk o tamaño de trabajo de cada hilo o tarea
        int size = (int) Math.ceil(arr.length * 1.0 / threads);

        //Creo un array de tareas
        SummationParallel[] sums = new SummationParallel[threads];

        //Asigno la tarea que le toca a cada hilo y lo lanzo.
        for (int i = 0; i < threads; i++) {
            sums[i] = new SummationParallel(arr, i * size, (i + 1) * size);
            sums[i].start();
        }

        //Espero a que TODOS los hilos creados antes terminen su tarea
        try {
            for (SummationParallel sum : sums) {
                sum.join();
            }
        } catch (InterruptedException e) { }

        int total = 0;

        //Sumo los parciales de cada hilo después de haber terminado
        for (SummationParallel sum : sums) {
            total += sum.getPartialSum();
        }

        return total;
    }

}