package main;

import java.util.Random;

import tasks.Summation;
import tasks.SummationParallel;

public class Snippet {

	public static void main(String[] args) {
		//Genera semilla 
		Random rand = new Random();
		System.out.println("Cantidad de procesadores: " + Runtime.getRuntime().availableProcessors());
		int[] arr = new int[1000000000];

		//Relleno el array con números del 1 al 100 aleatoriamente.
		for (int i = 0; i < arr.length; i++) {
			arr[i] = rand.nextInt(100) + 1; // 1..100
		}

		//Capto el momento de antes de empezar la suma monohilo.
		long start = System.currentTimeMillis();

		Summation.sum(arr);

		//Digo el tiempo que ha tardado la suma monohilo
		System.out.println("Single: " + (System.currentTimeMillis() - start)); 

		//Capto el momento de antes de empezar la suma multihilo.
		start = System.currentTimeMillis();

		SummationParallel.parallelSum(arr);

		//Digo el tiempo que ha tardado la suma multihilo
		System.out.println("Parallel: " + (System.currentTimeMillis() - start)); 
	}
}
